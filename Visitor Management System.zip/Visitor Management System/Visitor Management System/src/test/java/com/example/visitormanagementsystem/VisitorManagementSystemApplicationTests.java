package com.example.visitormanagementsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VisitorManagementSystemApplicationTests {

    @Test
    void contextLoads() {
    }

}
